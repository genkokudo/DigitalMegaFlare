﻿using DigitalMegaFlare.Entities;
using System.Linq;
namespace DigitalMegaFlare.Infrastructure.Database
{
	/// <summary>
	/// DBのマスタデータを初期化します。
	/// </summary>
	public class DbInitializer
	{
		public static void Initialize(ApplicationDbContext context)
		{
			if (context.Samples.Any())
			{
				// マスタデータ作成済ならば何もしない
				return;
			}
			
			// サンプルモデルの初期化
			context.Sample.AddRange(SampleEntity.GetInitialData());
			context.SaveChanges();
			
			// いいいいの初期化
			context.Magical.AddRange(MagicalEntity.GetInitialData());
			context.SaveChanges();

		}
	}
}