﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace DigitalMegaFlare.Entities
{
	/// <summary>
	/// ああああです。
	/// </summary>
	public class MiracleEntity
	{
		/// <summary>
		/// IDを取得、もしくは、設定します。
		/// </summary>
		[Key]
		public long MiracleId { get; set; }
		
		/// <summary>
		/// 名前を取得、もしくは、設定します。
		/// </summary>
		[StringLength(100)]
		public string Name { get; set; }
		
		/// <summary>
		/// 点数を取得、もしくは、設定します。
		/// </summary>
		public int Score { get; set; }
	}
}