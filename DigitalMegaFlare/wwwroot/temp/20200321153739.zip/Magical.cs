﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace DigitalMegaFlare.Models
{
	/// <summary>
	/// いいいい
	/// </summary>
	public class Magical
	{
		/// <summary>
		/// 通し番号
		/// </summary>
		[Key]
		public long Id { get; set; }
		
		/// <summary>
		/// 名前A
		/// </summary>
		[StringLength(50)]
		public string NameA { get; set; }
		
		/// <summary>
		/// 点数B
		/// </summary>
		public int ScoreB { get; set; }
		/// <summary>
		/// 並び順
		/// </summary>
		public int Order { get; set; }
		
		/// <summary>
		/// 初期値を作成する
		/// </summary>
		/// <returns></returns>
		internal static Magical[] GetInitialData()
		{
			var result = new List<Magical>();
			var order = 0;
			for (int i = 0; i < .Count(); i++)
			{
				order++;
				result.Add(new Magical()
				{
					Order = order,
					NameA = [i],
					ScoreB = [i],
				});
			}
			return result.ToArray();
		}
	}
}

